var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'alsuepsm',
applicationName: 'apollo-lambda-app',
appUid: 'ffpGz9WGl5vNvnx7cB',
tenantUid: '76TtzZNskkMZYDfxrv',
deploymentUid: '4ea423ba-bfef-41f2-91aa-2e6d05a0534b',
serviceName: 'zzan-api',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'zzan-api-dev-graphql', timeout: 6}
try {
  const userHandler = require('./src/index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
